package com.axo.music

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class Track(
    val id: String,
    val name: String,
    val artist_name: String,
    val album_name: String? = null,
    val duration: Int = 0,
    val image: String? = null,
    val audio: String? = null,
    val audiodownload: String? = null,
    val audiodownload_allowed: Boolean? = null,
)

data class TracksResponse(val results: List<Track> = emptyList())

interface JamendoApi {
    @GET("tracks/")
    suspend fun tracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 30,
        @Query("search") search: String? = null,
        @Query("tags") tags: String? = null,
        @Query("order") order: String? = null,
        @Query("imagesize") imageSize: Int = 500,
        @Query("audioformat") audioFormat: String = "mp32",
        @Query("audiodlformat") audioDlFormat: String = "mp32",
    ): TracksResponse
}

/** Catalog provider backed by Jamendo (Creative Commons licensed music, streaming allowed). */
object Catalog {
    private val api: JamendoApi = Retrofit.Builder()
        .baseUrl("https://api.jamendo.com/v3.0/")
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(JamendoApi::class.java)

    private val id get() = BuildConfig.JAMENDO_CLIENT_ID

    val configured get() = id.isNotBlank()

    suspend fun trending() = api.tracks(id, order = "popularity_week").results.filter { !it.audio.isNullOrBlank() }
    suspend fun search(q: String) = api.tracks(id, search = q).results.filter { !it.audio.isNullOrBlank() }
    suspend fun byTag(tag: String) = api.tracks(id, tags = tag, order = "popularity_month").results.filter { !it.audio.isNullOrBlank() }
}
