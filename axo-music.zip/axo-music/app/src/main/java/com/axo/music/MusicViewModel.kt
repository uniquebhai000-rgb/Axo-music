package com.axo.music

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("axo", Context.MODE_PRIVATE)
    private val gson = Gson()
    private var controller: MediaController? = null
    private var queue: List<Track> = emptyList()

    var trending by mutableStateOf<List<Track>>(emptyList())
    var chill by mutableStateOf<List<Track>>(emptyList())
    var electronic by mutableStateOf<List<Track>>(emptyList())
    var results by mutableStateOf<List<Track>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var searched by mutableStateOf(false)

    var current by mutableStateOf<Track?>(null)
    var isPlaying by mutableStateOf(false)
    var position by mutableStateOf(0L)
    var duration by mutableStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableStateOf(Player.REPEAT_MODE_OFF)
    var liked by mutableStateOf(loadLiked())

    init {
        connect()
        loadHome()
        viewModelScope.launch {
            while (true) {
                controller?.let {
                    position = it.currentPosition
                    duration = it.duration.coerceAtLeast(0L)
                }
                delay(500)
            }
        }
    }

    private fun connect() {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    current = queue.firstOrNull { it.id == item?.mediaId }
                }
            })
        }, MoreExecutors.directExecutor())
    }

    fun loadHome() = viewModelScope.launch {
        if (!Catalog.configured) {
            error = "Add your free Jamendo client ID (see README) to load music."
            return@launch
        }
        loading = true; error = null
        try {
            trending = Catalog.trending()
            chill = Catalog.byTag("chillout")
            electronic = Catalog.byTag("electronic")
        } catch (e: Exception) { error = "Could not load music: ${e.message}" }
        loading = false
    }

    fun search(q: String) = viewModelScope.launch {
        if (q.isBlank() || !Catalog.configured) return@launch
        loading = true; error = null; searched = true
        try { results = Catalog.search(q) } catch (e: Exception) { error = "Search failed: ${e.message}" }
        loading = false
    }

    fun play(list: List<Track>, index: Int) {
        val c = controller ?: return
        queue = list
        val items = list.map { t ->
            MediaItem.Builder().setMediaId(t.id).setUri(t.audio)
                .setMediaMetadata(
                    MediaMetadata.Builder().setTitle(t.name).setArtist(t.artist_name)
                        .setAlbumTitle(t.album_name)
                        .setArtworkUri(t.image?.let { android.net.Uri.parse(it) }).build()
                ).build()
        }
        c.setMediaItems(items, index, 0L)
        c.prepare(); c.play()
        current = list[index]
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun skip(ms: Long) { controller?.let { it.seekTo((it.currentPosition + ms).coerceAtLeast(0)) } }
    fun toggleShuffle() { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle }
    fun cycleRepeat() {
        repeat = when (repeat) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller?.repeatMode = repeat
    }

    fun toggleLike(t: Track) {
        liked = if (liked.any { it.id == t.id }) liked.filterNot { it.id == t.id } else liked + t
        prefs.edit().putString("liked", gson.toJson(liked)).apply()
    }

    private fun loadLiked(): List<Track> = try {
        gson.fromJson(prefs.getString("liked", "[]"), object : TypeToken<List<Track>>() {}.type) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    override fun onCleared() { controller?.release(); super.onCleared() }
}
