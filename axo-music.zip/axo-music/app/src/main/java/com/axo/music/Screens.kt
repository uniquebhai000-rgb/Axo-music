package com.axo.music

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage

private fun greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when { h < 12 -> "Good Morning"; h < 18 -> "Good Afternoon"; else -> "Good Evening" }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun AxoApp(vm: MusicViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    val bgBrush = Brush.verticalGradient(listOf(Color(0xFF1B1030), Bg, Bg))

    if (showPlayer && vm.current != null) {
        BackHandler { showPlayer = false }
        PlayerScreen(vm) { showPlayer = false }
        return
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column {
                if (vm.current != null) MiniPlayer(vm) { showPlayer = true }
                NavigationBar(containerColor = Bg2) {
                    listOf(
                        Triple("Home", Icons.Default.Home, 0),
                        Triple("Search", Icons.Default.Search, 1),
                        Triple("Library", Icons.Default.LibraryMusic, 2),
                    ).forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White, selectedTextColor = Neon,
                                indicatorColor = Purple, unselectedIconColor = Subtle, unselectedTextColor = Subtle
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().background(bgBrush).padding(pad)) {
            when (tab) {
                0 -> HomeScreen(vm)
                1 -> SearchScreen(vm)
                else -> LibraryScreen(vm)
            }
        }
    }
}

@Composable
fun HomeScreen(vm: MusicViewModel) {
    LazyColumn(contentPadding = PaddingValues(vertical = 16.dp)) {
        item {
            Text("AXO MUSIC", color = Neon, fontWeight = FontWeight.Black, fontSize = 14.sp,
                letterSpacing = 4.sp, modifier = Modifier.padding(horizontal = 16.dp))
            Text(greeting(), fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp))
            Text("Feel Every Beat.", color = Subtle, modifier = Modifier.padding(start = 16.dp, bottom = 12.dp))
        }
        if (vm.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp), color = Neon) }
        vm.error?.let { e ->
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(e, color = Violet)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.loadHome() }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Retry") }
                }
            }
        }
        item { Shelf("Trending Now", vm.trending, vm) }
        item { Shelf("Chill Vibes", vm.chill, vm) }
        item { Shelf("Electronic", vm.electronic, vm) }
    }
}

@Composable
fun Shelf(title: String, tracks: List<Track>, vm: MusicViewModel) {
    if (tracks.isEmpty()) return
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp))
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(tracks) { i, t ->
            Column(Modifier.width(140.dp).clickable { vm.play(tracks, i) }) {
                AsyncImage(t.image, t.name, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(140.dp).clip(RoundedCornerShape(14.dp)).background(Bg2))
                Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp))
                Text(t.artist_name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Subtle, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SearchScreen(vm: MusicViewModel) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("Songs, artists, genres") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(q) }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Purple)
        )
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Neon)
        vm.error?.let { Text(it, color = Violet, modifier = Modifier.padding(top = 8.dp)) }
        if (vm.searched && !vm.loading && vm.results.isEmpty() && vm.error == null)
            Text("No playable results found.", color = Subtle, modifier = Modifier.padding(top = 16.dp))
        TrackList(vm.results, vm)
    }
}

@Composable
fun TrackList(tracks: List<Track>, vm: MusicViewModel) {
    LazyColumn {
        itemsIndexed(tracks) { i, t ->
            Row(Modifier.fillMaxWidth().clickable { vm.play(tracks, i) }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(t.image, null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)).background(Bg2))
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text("${t.artist_name} • ${fmt(t.duration * 1000L)}", color = Subtle, fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { vm.toggleLike(t) }) {
                    val on = vm.liked.any { it.id == t.id }
                    Icon(if (on) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder, "Like",
                        tint = if (on) Neon else Subtle)
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(vm: MusicViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Liked Songs", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (vm.liked.isEmpty()) Text("Tap the heart on any song to save it here.", color = Subtle,
            modifier = Modifier.padding(top = 12.dp))
        TrackList(vm.liked, vm)
    }
}

@Composable
fun MiniPlayer(vm: MusicViewModel, onOpen: () -> Unit) {
    val t = vm.current ?: return
    Column(Modifier.fillMaxWidth().background(Color(0xFF1A1228)).clickable { onOpen() }) {
        val p = if (vm.duration > 0) vm.position.toFloat() / vm.duration else 0f
        LinearProgressIndicator(progress = { p.coerceIn(0f, 1f) }, Modifier.fillMaxWidth().height(2.dp),
            color = Neon, trackColor = Color.Transparent)
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(t.image, null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(t.artist_name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Subtle, fontSize = 12.sp)
            }
            IconButton(onClick = { vm.togglePlay() }) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color.White)
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
}

@Composable
fun PlayerScreen(vm: MusicViewModel, onClose: () -> Unit) {
    val t = vm.current ?: return
    val glow by rememberInfiniteTransition(label = "glow").animateFloat(
        0.35f, 0.9f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "g")
    val scale by animateFloatAsState(if (vm.isPlaying) 1f else 0.9f, tween(400), label = "s")
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF2A1450), Bg)))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Text("NOW PLAYING", color = Violet, letterSpacing = 3.sp, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize(0.92f * scale).shadow(40.dp, RoundedCornerShape(24.dp),
                ambientColor = Neon, spotColor = Neon).alpha(glow).background(Neon, RoundedCornerShape(24.dp)))
            AsyncImage(t.image, t.name, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(0.9f * scale).clip(RoundedCornerShape(24.dp)).background(Bg2))
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist_name, color = Subtle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val on = vm.liked.any { it.id == t.id }
            IconButton(onClick = { vm.toggleLike(t) }) {
                Icon(if (on) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder, "Like", tint = if (on) Neon else Subtle)
            }
        }
        val dur = vm.duration.coerceAtLeast(1L).toFloat()
        Slider(
            value = if (dragging) dragPos else (vm.position / dur).coerceIn(0f, 1f),
            onValueChange = { dragging = true; dragPos = it },
            onValueChangeFinished = { vm.seekTo((dragPos * dur).toLong()); dragging = false },
            colors = SliderDefaults.colors(thumbColor = Neon, activeTrackColor = Neon, inactiveTrackColor = Color(0xFF3A2D55))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(vm.position), color = Subtle, fontSize = 12.sp)
            Text(fmt(vm.duration), color = Subtle, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (vm.shuffle) Neon else Subtle)
            }
            IconButton(onClick = { vm.previous() }) { Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(36.dp)) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Neon)))
                .clickable { vm.togglePlay() }, contentAlignment = Alignment.Center) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                    Modifier.size(40.dp), tint = Color.White)
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next", Modifier.size(36.dp)) }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repeat",
                    tint = if (vm.repeat == Player.REPEAT_MODE_OFF) Subtle else Neon)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            IconButton(onClick = { vm.skip(-10_000) }) { Icon(Icons.Default.Replay10, "Back 10s", tint = Subtle) }
            IconButton(onClick = { vm.skip(10_000) }) { Icon(Icons.Default.Forward10, "Forward 10s", tint = Subtle) }
        }
    }
}
