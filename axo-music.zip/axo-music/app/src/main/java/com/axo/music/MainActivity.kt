package com.axo.music

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF08070D)
val Bg2 = Color(0xFF100D19)
val Purple = Color(0xFF8B5CF6)
val Neon = Color(0xFFA855F7)
val Violet = Color(0xFFC084FC)
val Subtle = Color(0xFFA5A0B2)

class MainActivity : ComponentActivity() {
    private val vm: MusicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Neon, secondary = Violet, background = Bg, surface = Bg2,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) { AxoApp(vm) }
        }
    }
}
