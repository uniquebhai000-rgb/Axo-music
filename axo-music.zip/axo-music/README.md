# AXO MUSIC — Feel Every Beat.

Android music app (Kotlin, Jetpack Compose, Material 3, Media3 ExoPlayer + MediaSession).
Black + purple neon design. Music comes from the **Jamendo** catalog (Creative Commons / licensed
for streaming), so playback is fully legal.

## Get the APK from GitHub
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Get a free client ID at https://devportal.jamendo.com (create an app).
3. In your repo: **Settings → Secrets and variables → Actions → New repository secret**
   - Name: `JAMENDO_CLIENT_ID`, Value: your client ID.
4. Push to `main` (or Actions → *Build AXO MUSIC APK* → *Run workflow*).
5. After ~5 min download `app-debug.apk` from the **Releases** page (tag `latest`) or the run's **Artifacts**.
6. Install on your phone (allow "install unknown apps").

## Local build
`gradle assembleDebug -PJAMENDO_CLIENT_ID=xxxx` (Gradle 8.9, JDK 17, Android SDK 34).

## What works now
Home shelves (trending, chill, electronic), search, full-screen neon player (play/pause, next/prev,
seek, ±10s, shuffle, repeat, like), mini player, background playback, notification + lock-screen
controls, Liked Songs library.

## Roadmap (not built yet — honest status)
Firebase auth, onboarding wizard, playlists, downloads (Jamendo CC tracks only), lyrics provider,
equalizer, AXO Live rooms (NestJS + WebSocket backend), AI DJ, Google Play Billing with server
verification, clips. Spotify/YouTube can be added as discovery-only providers; they do not grant
playback or download rights.
